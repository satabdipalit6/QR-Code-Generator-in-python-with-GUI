import tkinter
from tkinter import *
import qrcode as qr
from PIL import Image,ImageTk
from resizeimage import resizeimage

class QR_Generator:
  def __init__(self,root):
      self.root=root
      self.root.geometry("900x500+200+50")
      self.root.title("QR CODE GENERATOR || Developed By CSE,BEST")
      self.root.resizable(False,False)
      self.root.configure(bg='blue')
      
      title=Label(text="QR CODE GENERATOR", font=("times new roman",40),bg="green").place(x=0,y=0,relwidth=1)
   #--------------------------------Code generator window--------------------#
      self.var_lbl1 = StringVar()
      
      app_window =Frame(self.root,bd=2,relief=RIDGE,bg='white')   
      app_window.place(x=50,y=90,width=480,height=380) 
      
      lbl1=Label(app_window,text="Website Name",font=("times new roman",20,'bold'),bg='red').place(x=0,y=0,relwidth=1)
      txt_lbl1=Entry(app_window,font=("times new roman",15,'bold'),textvariable=self.var_lbl1,bg='#CEC0DF',fg='black').place(x=80,y=80,width=300)
      
      btn_generate=Button(app_window,text="QR Generate",command= self.qrcode,font=("Times new roman",18,'bold'),bg='#0EF78A').place(x=50,y=200,width=200)
      btn_clear=Button(app_window,text="Clear",command=self.clear,font=("Times new roman",18,'bold'),bg='#0EF78A').place(x=280,y=200,width=150)
      
      self.msg=''
      self.lbl_msg=Label(app_window,text=self.msg,font=("times new roman",15,'bold'),bg='white',fg='green')
      self.lbl_msg.place(x=20,y=260,relwidth=1)     
   #--------------------------------QR code image-----------------------------#
      qrcode_window =Frame(self.root,bd=2,relief=RIDGE,bg='white')   
      qrcode_window.place(x=560,y=90,width=300,height=380) 
      
      lbl2=Label(qrcode_window,text="QR Code",font=("times new roman",20,'bold'),bg='red').place(x=0,y=0,relwidth=1)
      
      self.qr_code=Label(qrcode_window,text='No qr\n Avaiable',font=('times new roman',15),bg='#3f51b5',fg='white')
      self.qr_code.place(x=60,y=90,width=190,height=190)
      
  def clear(self):
       self.var_lbl1.set('') 
       self.msg=''
       self.lbl_msg.config(text=self.msg)
       self.qr_code.config(image='')
        
       
       
       
  def qrcode(self):
       if self.var_lbl1.get()=='':
          self.msg='This field should be filled!!!'
          self.lbl_msg.config(text=self.msg,fg='red')
       else:
          #-------------------QR code Generate---------------#
          da=self.var_lbl1.get()
          qr_img= qr.make(da)
          qr_img=resizeimage.resize_cover(qr_img,[190,190])
          qr_img.save(str(da)+'.png')
          self.img=ImageTk.PhotoImage(file=str(da)+'.png')
          self.qr_code.config(image=self.img)
         #  
         #  print(da)
         #  data = qr.make(f"Website Name:{self.var_lbl1.get()}")
         #  qr_code=qr.make(data)
         #  qr_code=resizeimage.resize_cover(qr_code,[190,190])
         #  qr_code.save("Website_QR"+str(self.var_lbl1.get())+'.png')
          
         #  self.img=ImageTk.PhotoImage(file="Website_QR"+str(self.var_lbl1.get())+'.png')
         #  self.qr_code.config(image=self.img)
          
          
          
          #--------------------------Notification-----------------#
          self.msg='QR Generated Successfully!!!'
          self.lbl_msg.config(text=self.msg,fg='green')
             
          
         
      
      
        

root=Tk()
obj=QR_Generator(root)
root.mainloop()

